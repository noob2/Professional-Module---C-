﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Box
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            List<Box<int>> items = new List<Box<int>>();

            for (int i = 0; i < n; i++)
            {
                var input = int.Parse(Console.ReadLine());
                items.Add(new Box<int>(input));
            }

            var swapIndexes = Array.ConvertAll(Console.ReadLine().Split(), int.Parse); 

            Swap(items, swapIndexes[0], swapIndexes[1]);

            foreach (var item in items)
            {
                Console.WriteLine(item);
            }
        }

        private static void Swap<T>(List<T> list, int a, int b)
        {
            T temp = list[a];

            list[a] = list[b];
            list[b] = temp;
        }
    }
}
